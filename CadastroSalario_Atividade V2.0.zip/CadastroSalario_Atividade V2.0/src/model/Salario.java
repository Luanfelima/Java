package model;

public class Salario
{
    private String nome;
    private String cpf;
    private int idade;
    private String salario;
    private String data;
    private String telefone;
    private String celular;
    private String email;
    private String sexo;
    private String cargo;
   
 
    public Salario (String nome, String cpf, int idade, String salario, String data, String telefone, String celular, String email, String sexo, String cargo)
    {
        this.nome = nome;
        this.cpf = cpf;
        this.idade = idade;
        this.salario = salario;
        this.data = data;
        this.telefone = telefone;
        this.celular = celular;
        this.email = email;
        this.sexo = sexo;
        this.cargo = cargo;
    }
        
    public String getNome()  //GET TEM RETORNO, ELE TRAS O VALOR ATE VOCE
    {
        return nome;
    }
    
    public void setNome(String nome)  //SET NAO RETORNA (VOID), MAS COLOCA A VARIAVEL NAQUELE LOCAL.
    {
        this.nome = nome;
    }
    
    public String getCpf()
    {
        return cpf;
    }
    
    public void setCpf(String cpf)
    {
        this.cpf = cpf;
    }
    
    public int getIdade()
    {
        return idade;
    }
    
    public void setIdade(int idade)
    {
        this.idade = idade;
    }
    
    public String getSalario() 
    {
        return salario;
    }
    
    public void setSalario(String salario)
    {
        this.salario = salario;
    }
    
    public String getData() 
    {
        return data;
    }
    
    public void setData(String data)
    {
        this.data = data;
    }

    public String getTelefone()
    {
        return telefone;
    }

    public void setTelefone(String telefone)
    {
        this.telefone = telefone;
    }
    
    public String getCelular()
    {
        return celular;
    }
    
    public void setCelular(String celular)
    {
        this.celular = celular;
    }
    
    public String getEmail()
    {
        return email;
    }
    
    public void setEmail(String email)
    {
        this.email = email;
    } 

    public String getSexo() 
    {
        return sexo;
    }

    public void setSexo(String sexo) 
    {
        this.sexo = sexo;
    }

    public String getCargo()
    {
        return cargo;
    }

    public void setCargo(String cargo) 
    {
        this.cargo = cargo;
    }  
}


