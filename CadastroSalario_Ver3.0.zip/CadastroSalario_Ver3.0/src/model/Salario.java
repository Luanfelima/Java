
package model;


public class Salario {
    private String nome;
    private String cpf;
    private String salario;
    private String idade;
    private String email;
    private String contato;

    public String getNome()
    {
        return nome;
    }

    public void setNome(String descricao)
    {
        this.nome = descricao;
    }

    public String getCpf()
    {
        return cpf;
    }

    public void setCpf(String cpf)
    {
        this.cpf = cpf;
    }

    public String getSalario()
    {
        return salario;
    }

    public void setSalario(String salario)
    {
        this.salario = salario;
    }

    public String getIdade() 
    {
        return idade;
    }

    public void setIdade(String idade)
    {
        this.idade = idade;
    }      

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String Email)
    {
        this.email = Email;
    }

    public String getContato()
    {
        return contato;
    }

    public void setContato(String contato)
    {
        this.contato = contato;
    }    
    
}

